﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Application_Common.Utility
{
    
    public class HttpClientFactory
    {
        private static readonly HttpClient httpClient = new HttpClient();

        public async Task<string> GetResult()
        {
            var result =await httpClient.GetAsync("http://www.baidu.com");

            return result.ToString();
        }
    }
}

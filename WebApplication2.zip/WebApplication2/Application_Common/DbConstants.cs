﻿using System;

namespace Application_Common
{
    public class DbConstants
    {
        #region 商品库

        public const string BusinessManager = "BusinessManager";

        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application_Common
{
    public class ConfigConstants
    {
        public const string BusinessManagerConnKey = "BusinessManagerConnKey";
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Application_Service.ICommodity;
using Application_Service.Model;
using Application_Service.Model.User;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication2.Controllers
{
    public class UserController : Controller
    {
        private readonly IQueryCommodityBll queryCommodityBll;
        public UserController(IQueryCommodityBll queryCommodityBll)
        {
            this.queryCommodityBll = queryCommodityBll;
        }
        public IActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// 用户登录
        /// </summary>
        /// <param name="userLogin"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<BaseResponse> UserLogin(UserLogin userLogin)
        {
            return await this.queryCommodityBll.UserLogin(userLogin);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Application_Service.IMongoBll;
using Application_Service.Model;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication2.Controllers
{
    public class MongoQueryController : Controller
    {
        private readonly IQueryBll queryBll;
        public MongoQueryController(IQueryBll queryBll) {

            this.queryBll = queryBll;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        [HttpPost]
        public async Task<List<UserInfo>> QueryByName(string userName) {
            if (string.IsNullOrEmpty(userName)) {
                return new List<UserInfo>();
            }

            return await this.queryBll.Query(userName);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Application_Service.ICommodity;
using Application_Service.Model;
using Application_Service.Model.Commodity;
using Application_Service.Model.Commodity.Query;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication2.Controllers
{
    public class ManagerController : Controller
    {
        private readonly IQueryCommodityBll queryCommodityBll;

        public ManagerController(IQueryCommodityBll queryCommodityBll)
        {
            this.queryCommodityBll = queryCommodityBll;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [HttpGet]
        public async Task<BaseResponse<List<CommodityInfo>>> GetCommodityInfo(CommodityRequest request)
        {
            var response = new BaseResponse<List<CommodityInfo>>();
            response.Data= this.queryCommodityBll.GetCommodityInfos(request);
            return response;
        }
    }
}
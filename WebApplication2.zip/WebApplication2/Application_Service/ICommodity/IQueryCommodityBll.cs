﻿using Application_Service.Model;
using Application_Service.Model.Commodity;
using Application_Service.Model.Commodity.Query;
using Application_Service.Model.User;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Application_Service.ICommodity
{
    public interface IQueryCommodityBll
    {
        /// <summary>
        /// 获取商品信息
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        List<CommodityInfo> GetCommodityInfos(CommodityRequest request);

        /// <summary>
        /// 用户登录
        /// </summary>
        /// <param name="userLogin"></param>
        /// <returns></returns>
        Task<BaseResponse> UserLogin(UserLogin userLogin);

        /// <summary>
        /// 用户注册
        /// </summary>
        /// <param name="userRegister"></param>
        /// <returns></returns>
        Task<BaseResponse> UserRegister(UserRegister userRegister);
    }
}

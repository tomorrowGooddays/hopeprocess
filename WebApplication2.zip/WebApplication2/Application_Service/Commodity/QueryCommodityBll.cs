﻿using Application_Common;
using Application_Data.Interface;
using Application_Service.ICommodity;
using Application_Service.Model;
using Application_Service.Model.Commodity;
using Application_Service.Model.Commodity.Query;
using Application_Service.Model.User;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application_Service.Commodity
{
    public class QueryCommodityBll : IQueryCommodityBll
    {
        private readonly IDataConnAdapter<MongoClient> dataConnAdapter;
        public QueryCommodityBll(IDataConnAdapter<MongoClient> dataConnAdapter)
        {
            this.dataConnAdapter = dataConnAdapter;
        }
        public UserLogin userLogins = new UserLogin() { UserName = "admin", Password = "111111", Checkbox = false };
        public List<CommodityInfo> GetCommodityInfos(CommodityRequest request)
        {
            var list = new List<CommodityInfo>()
            {
                new CommodityInfo(){
                    Name="西游记",
                    Cate="智能",
                    Tag="呵呵",
                    Store="测试1",
                    Sales = 1000,
                    Service="可预约"
                },
                new CommodityInfo(){
                    Name="诚实吧",
                    Cate="数码",
                    Tag="哈哈",
                    Store="测试2",
                    Sales = 1300,
                    Service="不可预约"
                },
                new CommodityInfo(){
                    Name="你好",
                    Cate="数码2",
                    Tag="哈哈333",
                    Store="测试233",
                    Sales = 1344,
                    Service="可预约"
                },
                new CommodityInfo(){
                    Name="诚实吧33",
                    Cate="数码4",
                    Tag="哈哈33",
                    Store="测试3",
                    Sales = 200,
                    Service="不可预约"
                },
            };
            if (request != null)
            {
                if (!string.IsNullOrEmpty(request.Name))
                {
                    list = list.Where(p => p.Name == request.Name).ToList();
                }

                if (!string.IsNullOrEmpty(request.Cate))
                {
                    list = list.Where(p => p.Cate == request.Cate).ToList();
                }

                if (!string.IsNullOrEmpty(request.Store))
                {
                    list = list.Where(p => p.Store == request.Store).ToList();
                }

            }

            return list;
        }

        public async Task<BaseResponse> UserLogin(UserLogin userLogin)
        {
            var response = new BaseResponse();

            try
            {
                response.Data = false;
                if (userLogin == null || string.IsNullOrEmpty(userLogin.UserName))
                {
                    throw new Exception("请输入正确的用户名");
                }

                if (userLogin.UserName != userLogins.UserName || userLogin.Password != userLogins.Password)
                {
                    throw new Exception("用户名或密码错误");
                }

                IMongoClient client = await this.dataConnAdapter.GetConnectionAsync(ConfigConstants.BusinessManagerConnKey);
                if (client != null)
                {
                    //var database = client.GetDatabase(DbConstants.BusinessManager);

                    //var collection = database.GetCollection<UserRegister>("UserRegister");

                    //await collection.InsertOneAsync(userRegister);

                    //FilterDefinitionBuilder<BsonDocument> builderFilter = Builders<BsonDocument>.Filter;
                    ////约束条件
                    //FilterDefinition<BsonDocument> filter = builder.Eq("DepartmentName", "开发部");
                }


                response.Data = true;
            }
            catch (Exception ex)
            {
                response.Message = ex.Message;
            }

            return response;
        }

        public async Task<BaseResponse> UserRegister(UserRegister userRegister)
        {
            var response = new BaseResponse() { Data = false };
            try
            {
                if (userRegister == null || string.IsNullOrEmpty(userRegister.Name) || string.IsNullOrEmpty(userRegister.Passwd))
                {
                    throw new Exception("用户名或密码为空");
                }

                if (userRegister.Passwd != userRegister.RePasswd)
                {
                    throw new Exception("两次输入密码不一致，请重新输入");
                }

                IMongoClient client = await this.dataConnAdapter.GetConnectionAsync(ConfigConstants.BusinessManagerConnKey);
                if (client != null)
                {
                    var database = client.GetDatabase(DbConstants.BusinessManager);
                    
                    var collection = database.GetCollection<UserRegister>("UserRegister");

                    await collection.InsertOneAsync(userRegister);
                }

                response.Data = true;
            }
            catch (Exception ex)
            {
                response.Message = ex.Message;
            }

            return response;
        }
    }
}

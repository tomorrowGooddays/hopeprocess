﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application_Service.Model.Commodity
{
    public class CommodityInfo
    {
        /// <summary>
        /// 名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 类型：0-数码，1-智能
        /// </summary>
        public string Cate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Tag { get; set; }

        public string Store { get; set; }

        public decimal Sales { get; set; }

        /// <summary>
        /// 是否可预约体检
        /// </summary>
        public string Service { get; set; }
    }
}

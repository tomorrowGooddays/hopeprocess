﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application_Service.Model.Commodity.Query
{
    public class CommodityRequest:BaseQueryRequest
    {
        public string Name { get; set; }

        public string Cate { get; set; }


        public string Store { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application_Service.Model
{
    public class BaseResponse<T> where T : class
    {
        public bool Success
        {
            get
            {
                if (!string.IsNullOrEmpty(Message))
                {
                    return false;
                }

                return true;
            }
        }

        public string Message { get; set; }

        public T Data { get; set; }
    }

    public class BaseResponse : BaseResponse<object>
    {

    }
}

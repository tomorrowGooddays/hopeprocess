﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application_Service.Model.User
{
    public class UserLogin
    {
        [JsonProperty("username")]
        public string UserName { get; set; }

        [JsonProperty("password")]
        public string Password { get; set; }

        [JsonProperty("checkbox")]
        public bool Checkbox { get; set; }
    }
}

﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application_Service.Model.User
{
    public class UserRegister
    {
        [JsonProperty("name")]
        public string Name { get; set; }
        
        [JsonProperty("email")]
        public string Emial { get; set; }

        [JsonProperty("passwd")]
        public string Passwd { get; set; }

        [JsonProperty("rePasswd")]
        public string RePasswd { get; set; }
    }
}

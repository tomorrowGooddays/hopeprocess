﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application_Service.Model {

    [BsonIgnoreExtraElements]
    public class UserInfo {

        [BsonElement("_id")]
        public string ID { get; set; }

        public string UserName { get; set; }


        public string Password { get; set; }

        public string Email { get; set; }
    }

}

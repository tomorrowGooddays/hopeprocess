﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application_Service.Model
{
    public class BaseQueryRequest
    {
        public int Page { get; set; } = 0;

        public int PageSize { get; set; } = 10;
    }
}

﻿using Application_Service.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Application_Service.IMongoBll {
    public interface IQueryBll {

        /// <summary>
        /// 查询
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        Task<List<UserInfo>> Query(string userName);
    }
}

﻿using Application_Common;
using Application_Data.Interface;
using Application_Service.IMongoBll;
using Application_Service.Model;
using MongoDB.Driver;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Application_Service.MongoBll {
    public class QueryBll : IQueryBll {

        private readonly IDataConnAdapter<MongoClient> dataConnAdapter;

        public QueryBll(IDataConnAdapter<MongoClient> dataConnAdapter) {
            this.dataConnAdapter = dataConnAdapter;
        }
        public async Task<List<UserInfo>> Query(string userName) {
            IMongoClient client = await this.dataConnAdapter.GetConnectionAsync(ConfigConstants.BusinessManagerConnKey);
            if (client != null) {

                var database = client.GetDatabase(DbConstants.BusinessManager);

                var collection = database.GetCollection<UserInfo>("UserInfo");

                var filterDef = Builders<UserInfo>.Filter.Eq(I => I.UserName, userName);

                return await collection.Find(filterDef).ToListAsync();

 ;            }

            return null;
        }
    }
}

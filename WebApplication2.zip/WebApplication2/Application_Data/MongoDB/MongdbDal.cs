﻿using Application_Data.Configuration;
using Application_Data.Interface;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace Application_Data.MongoDB {
    public class MongdbDal : IDataConnAdapter<MongoClient> {

        private readonly AVConfiguration configuration;
        public MongdbDal(AVConfiguration configuration) {
            this.configuration = configuration;
        }

        public static ConcurrentDictionary<string, MongoClient> DicDataBase = new ConcurrentDictionary<string, MongoClient>();
        public MongoClient DataBase => throw new NotImplementedException();

        public MongoClient GetConnection(string connStr) {
            throw new NotImplementedException();
        }

        /// <summary>
        /// 根据配置文件key获取连接
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public async Task<MongoClient> GetConnectionAsync(string name) {
           if(!DicDataBase.TryGetValue(name,out MongoClient database) || database == null) {
                string connStr = this.configuration.ConfigurationExtension.GetConfigInfo<string>(name, "");

                if (!string.IsNullOrEmpty(connStr)) {
                    database = new MongoClient(connStr);

                    DicDataBase.TryAdd(name, database);
                }

                return database;
            }

            return null;
        }
    }
}

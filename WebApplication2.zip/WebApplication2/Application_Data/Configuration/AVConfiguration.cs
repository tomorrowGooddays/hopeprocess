﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;

namespace Application_Data.Configuration {
    public class AVConfiguration {
        IServiceProvider _serviceProvider;
        IConfiguration _configuration;

        public ConfigurationExtension ConfigurationExtension { get; private set; }

        public AVConfiguration(IServiceProvider serviceProvider) {
            _serviceProvider = serviceProvider;
            _configuration = _serviceProvider.GetService<IConfiguration>();

            ConfigurationExtension = new ConfigurationExtension(_configuration);
        }
    }
}

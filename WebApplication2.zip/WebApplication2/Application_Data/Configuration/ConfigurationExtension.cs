﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application_Data.Configuration {
    public class ConfigurationExtension {
        IConfiguration _configuration;

        public ConfigurationExtension(IConfiguration configuration) {
            _configuration = configuration;
        }

        public T GetConfigInfo<T>(string section, T defaultValue) {
            try {
                return _configuration.GetValue<T>(section, defaultValue);
            } catch { }

            return defaultValue;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Application_Data.Interface {
    public interface IDataConnAdapter<T> where T: class {

        /// <summary>
        /// 获取数据库
        /// </summary>
        T DataBase { get; }

        /// <summary>
        /// 获取连接
        /// </summary>
        /// <param name="connStr"></param>
        /// <returns></returns>
        T GetConnection(string connStr);

        /// <summary>
        /// 获取连接
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        Task<T> GetConnectionAsync(string name);
    }
}
